import numpy as np
import os
import sys

# Script arguments
main_path = sys.argv[1]
rml_filename = sys.argv[2]
energy_range = sys.argv[3]
output_type = sys.argv[4]

# Energy variables (in ADC)
ZERO_KEV="0.0"
LIMIT_3="11838.6101694915" #limit sup of the 3 keV range
LIMIT_6='31154.2372881356'
TEN_KEV = '35000'
TWELVE_KEV="37385.0847457627"

# Find the path of this script:
path_bg = os.path.dirname(os.path.abspath(__file__))
# Remove rml file if existing:
if os.path.exists(path_bg+'/'+rml_filename):
    os.remove(path_bg+'/'+rml_filename)
 
path_rml_filename = main_path+'/Background/Raw_Background/'+rml_filename

file1 = open(path_rml_filename, 'w')
file1.write('<?xml version="1.0" encoding="UTF-8" standalone="no" ?>\n\n\n')
file1.write('<TRestManager name="SpecPlot" title="Example" verboseLevel="info" > \n\n')
file1.write('\t<TRestAnalysisPlot name="histoEnergy" title="Energy spectrum with XRay cuts" previewPlot="false" verboseLevel="silent">\n\n')

file1.write('\t<canvas size="(1000,1000)" divide="(1,1)" save="'+ path_bg +'/hitsEnergy_R[fRunNumber]_[fRunTag]_0to12keV_48bins_Fe55_'+ energy_range+'_NOCuts.'+output_type+'" />\n\n')

file1.write('<!-- ################################################################## -->\n<!-- TRACK CUTS -->\n\n')
file1.write('\t<globalCut variable="tckAna_nTracks_X" condition="==1" value="OFF"/>\n')
file1.write('\t<globalCut variable="tckAna_nTracks_Y" condition="==1" value="OFF"/>\n\n')
file1.write('\t<globalCut variable="hitsAna_nHitsX" condition=">0" value="ON" />\n')
file1.write('\t<globalCut variable="hitsAna_nHitsY" condition=">0" value="ON" />\n\n')
file1.write('<!-- ################################################################## -->\n<!-- SPATIAL CUTS -->\n')
file1.write('\t<globalCut variable="hitsAna_distanceToPrismWall" condition=">15" value="OFF"/>\n\n')
file1.write('\t<!-- Circle -->\n')
file1.write('\t<globalCut variable="hitsAna_xMean*hitsAna_xMean+hitsAna_yMean*hitsAna_yMean" condition="<100" value="ON"/> <!-- condition values is radius² -->\n\n')
file1.write('\t<!-- Ring -->\n')
file1.write('\t<globalCut variable="hitsAna_xMean*hitsAna_xMean+hitsAna_yMean*hitsAna_yMean" condition="<900" value="OFF"/> <!-- Outer radius. Condition values is radius² -->\n')
file1.write('\t<globalCut variable="hitsAna_xMean*hitsAna_xMean+hitsAna_yMean*hitsAna_yMean" condition=">400" value="OFF"/> <!-- Inner radius. Condition values is radius² -->\n\n\n')
file1.write('<!-- ################################################################## -->\n<!-- MUON VETO CUTS -->\n\n')
file1.write('\t<!--Range with no veto amplitude cut -->\n')
file1.write('\t<globalCutString string="veto_PeakTime<100||veto_PeakTime>300" value="OFF"/>\n\n')
file1.write('\t<!--Range with veto cuts -->\n')
file1.write('\t<globalCut variable="veto_MaxPeakAmplitude" condition="<200" value="OFF" />\n')
file1.write('\t<globalCut variable="veto_PeakTime" condition="<=300" value="OFF" />\n')
file1.write('\t<globalCut variable="veto_PeakTime" condition=">=100" value="OFF" />\n\n\n')
file1.write('<!-- ################################################################## -->\n')
file1.write('<!-- ENERGY CUT al-->\n\n')

if energy_range=='3keV':
    file1.write('\t<globalCut variable="hitsAna_energy" condition=">${ZERO_KEV}" value="ON"/>     <!-- Min of the calibrated range with Fe55 (0 keV)-->\n')
    file1.write('\t<globalCut variable="hitsAna_energy" condition="<=${LIMIT_3}" value="ON"/> <!-- Max of the calibrated range with Fe55 (3.8 keV)-->\n\n\n')
if energy_range=='5.9keV':
    file1.write('\t<globalCut variable="hitsAna_energy" condition=">${LIMIT_3}" value="ON"/>     <!-- Min of the calibrated range with Fe55 (3.8keV)-->\n')
    file1.write('\t<globalCut variable="hitsAna_energy" condition="<=${TWELVE_KEV}" value="ON"/> <!-- Max of the calibrated range with Fe55 (10keV)-->\n\n\n')

file1.write('<!--============================-->\n<!-- PLOT-->\n\n')
file1.write('\t<plot name="Spectrum" title="Hits Analysis energy spectrum" xlabel="Hits energy [ADC units]" ylabel="Counts" logscale="true" save="" annotation="ON" stats="ON" value="ON" >\n\n')
file1.write('\t\t<histo name="HitsEnergy">\n')
file1.write('\t\t\t<variable name="hitsAna_energy" range="(${ZERO_KEV},${TWELVE_KEV})" nbins="48" />\n')
file1.write('\t\t\t\t</histo>\n')
file1.write('\t\t</plot>\n\n')
file1.write('\t</TRestAnalysisPlot>\n\n')
file1.write('\t<addTask command="histoEnergy->PlotCombinedCanvas()" value="ON" />\n')
file1.write('</TRestManager>')

file1.close()

