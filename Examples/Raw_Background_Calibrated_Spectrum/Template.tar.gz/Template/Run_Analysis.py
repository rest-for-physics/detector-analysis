import numpy as np
import os
import matplotlib.pyplot as plt


# Define data path:
data_path =  '/local/home/bb263328/Desktop/REST_Analysis/CAST_Analysis_10418_10455/Raw_data'

# Find the path of this script:
path = os.path.dirname(os.path.abspath(__file__))
print(path,'\n')

##############################################################
# MANAGE FILE LISTS

# Open list of files to analyze:
# !!! Each calibration file must be placed right after the related bg file!!! 

file_list= np.loadtxt('list_CAST_run.txt', dtype=np.str)

# Create the background file list:
file0 = open('list_background_runs.txt', 'w')
for i in range (0,file_list.size):
    if 'Background' in file_list[i]:
        #s=file_list[i]+'\n'
        file0.write(file_list[i]+'\n')
file0.close()

# Read background run-list:
background_list = np.loadtxt('list_background_runs.txt', dtype=np.str)


##############################################################
# RAW TO SIGNAL ANALYSIS

# Write an sh file with the REST commands to run the first part of the analysis (rawToSignal.rml) on all files:
file_runAnalysis_part1=path+'/Raw_to_Track_Analysis/Run_rawToSignal.sh'

if os.path.exists(file_runAnalysis_part1):
    os.remove(file_runAnalysis_part1)

file1 = open(file_runAnalysis_part1, 'a')
file1.write('#!/bin/bash\n')
for i in range (0,file_list.size):
    s='restManager --c '+path+'/Raw_to_Track_Analysis/rawToSignal.rml --f '+data_path+'/'+file_list[i]+'\n'
    file1.write(s)
file1.close()

# Run the bash script for the first part of the analysis:
#bashCommand = '. '+file_runAnalysis_part1
#os.system(bashCommand)

##############################################################
# SIGNAL TO TRACK ANALYSIS

# Write the list with the output root-files of the first part of the analysis: 

if os.path.exists('Raw_to_Track_Analysis/RawtoSignal/list_rawToSignal.txt'):
    os.remove('Raw_to_Track_Analysis/RawtoSignal/list_rawToSignal.txt')

bashCommand = 'ls '+path+'/Raw_to_Track_Analysis/RawtoSignal/*root >> '+path+'/Raw_to_Track_Analysis/RawtoSignal/list_rawToSignal.txt'
os.system(bashCommand)

# Read the list:
file_list_rawToSignal = np.loadtxt("Raw_to_Track_Analysis/RawtoSignal/list_rawToSignal.txt", dtype=np.str)

# Write an sh file with the REST commands to run the second part of the analysis (signalToTrack.rml) on all files:
file_runAnalysis_part2=path+'/Raw_to_Track_Analysis/Run_signalToTrack.sh'

if os.path.exists(file_runAnalysis_part2):
    os.remove(file_runAnalysis_part2)

file2 = open(file_runAnalysis_part2, 'a')
file2.write('#!/bin/bash\n')
for i in range (0,file_list_rawToSignal.size):
    s='restManager --c '+path+'/Raw_to_Track_Analysis/signalToTrack.rml --f '+file_list_rawToSignal[i]+'\n'
    file2.write(s)
file2.close()

# Run the bash script for the second part of the analysis:
#bashCommand = '. '+file_runAnalysis_part2
#os.system(bashCommand)

##############################################################
# OBSERVABLE PLOTS

# Write a list with the output root-files signalToTrack:
if os.path.exists(path+'/Raw_to_Track_Analysis/SignalToTrack/list_signalToTrack.txt'):
    os.remove(path+'/Raw_to_Track_Analysis/SignalToTrack/list_signalToTrack.txt')

bashCommand = 'ls '+path+'/Raw_to_Track_Analysis/SignalToTrack/*root >>'+path+'/Raw_to_Track_Analysis/SignalToTrack/list_signalToTrack.txt'
os.system(bashCommand)

# Read the list:
file_list_signalToTrack = np.loadtxt("Raw_to_Track_Analysis/SignalToTrack/list_signalToTrack.txt", dtype=np.str)

# Write the sh file with the list of REST commands to generate the observable plots:
file_observable_plot=path+"/Raw_to_Track_Analysis/Observable_plots/Run_Observable_Plots.sh"

if os.path.exists(file_observable_plot):
    os.remove(file_observable_plot)

file3 = open(file_observable_plot, 'a')
file3.write('#!/bin/bash\n')
for i in range (0,file_list_signalToTrack.size):
    s='restManager --c ' +path+'/Raw_to_Track_Analysis/Observable_plots/Observable_plots_ONE_Track.rml --f '+file_list_signalToTrack[i]+'\n'
    file3.write(s)
file3.close()

# Run the bash script to generate the observable plots:
#bashCommand = '. '+file_observable_plot
#os.system(bashCommand)
# Move the plots in the Observable_plots directory (plots are created in the directory of this script):
bashCommand = 'mv Observables_ONE* Raw_to_Track_Analysis/Observable_plots '
os.system(bashCommand)

# Write the list of (only) analyzed background files (useful for next steps):
file_analyzed_bg=path+'/Raw_to_Track_Analysis/SignalToTrack/list_analyzed_file_background.txt'
file_bg = open(file_analyzed_bg, 'w')
for i in range (0,file_list_signalToTrack.size):
    if 'Background' in file_list_signalToTrack[i]:
        file_bg.write(file_list_signalToTrack[i]+'\n')
file_bg.close()

##############################################################
# FIND THE RELATION ADC-keV FROM CALIBRATION RUNS

#==========================================================
# Generate the calibration spectra (root histograms).

# Write the sh file with the REST commands to generate the spectra (in ADC):
file_generate_cal_spec=path+"/Calibration_spectra/Run_Calibration_Spectra.sh"

if os.path.exists(file_generate_cal_spec):
    os.remove(file_generate_cal_spec)

file4 = open(file_generate_cal_spec, 'a')
file4.write('#!/bin/bash\n')
for i in range (0,file_list_signalToTrack.size):
    if 'Calibration' in file_list_signalToTrack[i]:
        s='restManager --c ' +path+'/Calibration_spectra/Calibration_spectrum.rml --f '+file_list_signalToTrack[i]+'\n'
        file4.write(s)
file4.close()

# Run the bash script to generate the histograms (root files):
#bashCommand = '. '+file_generate_cal_spec
#os.system(bashCommand)
# ! If you change the ouput filename, you need to change it here!
bashCommand = 'mv Calibration* Calibration_spectra '
os.system(bashCommand)

#==========================================================
# Fit the 3 and 6 keV peaks with Root.

# Write two lists (one with the full path) containing the root histograms:
if os.path.exists(path+'/Calibration_spectra/histogram_list.txt'):
    os.remove(path+'/Calibration_spectra/histogram_list.txt')
bashCommand = 'ls '+path+'/Calibration_spectra/*root >> '+path+'/Calibration_spectra/histogram_list.txt'
os.system(bashCommand)

if os.path.exists(path+'/Calibration_spectra/histogram_names.txt'):
    os.remove(path+'/Calibration_spectra/histogram_names.txt')
bashCommand = 'ls Calibration_spectra/*root >> Calibration_spectra/histogram_names.txt'
os.system(bashCommand)

# Read the lists:
histogram_list = np.loadtxt("Calibration_spectra/histogram_list.txt", dtype=np.str) #full path
calibration_run_name = np.loadtxt("Calibration_spectra/histogram_names.txt", dtype=np.str) # only file names

# Write a bash script to run a root macro on files that:
# - fit the 3 and 6 keV peaks;
# - draw the fitted spectra into png files;
# - write the results of the fit into a txt file.

file_fitPeaks_Root_macro=path+"/Calibration_spectra/Run_FitPeaks_RootMacro.sh"

if os.path.exists(file_fitPeaks_Root_macro):
    os.remove(file_fitPeaks_Root_macro)

file5 = open(file_fitPeaks_Root_macro, 'a')
file5.write('#!/bin/bash\n')
for i in range (0,histogram_list.size):
    s1='restRoot <<EOF\n'
    s2='.x '+path+'/Calibration_spectra/fit_the_peaks.C("'+histogram_list[i]+'","'+calibration_run_name[i]+'");\n'
    s3='EOF\n'
    file5.write(s1)
    file5.write(s2)
    file5.write(s3)
file5.close()

# Remove existing file "fitted_peaks.dat" before running Root from bash:
if os.path.exists("Calibration_spectra/fitted_peaks.dat"):
    os.remove("Calibration_spectra/fitted_peaks.dat")
    
# Run the bash script to generate the calibration spectra:
bashCommand = '. '+file_fitPeaks_Root_macro
os.system(bashCommand)
# Move spectra in the Calibration_spectra directory. Plots are generated in the main directory.
bashCommand = 'mv *png Calibration_spectra'
os.system(bashCommand)

# Add a fisrt description line to file "fitted_peaks.dat":
with open('Calibration_spectra/fitted_peaks.dat') as f: 
	updatedfile='# Cal_run_number\t\t\t3keV peak\t3kev_peak_err\t6keV peak\t6kev_peak_err\tslope\tcoeff\tADC(3.8 keV)\tADC(10 keV)\tADC(12 keV)\n'+f.read() 
with open('Calibration_spectra/fitted_peaks.dat','w') as f: 
	f.write(updatedfile)

# Remove the histogram list containing just the filenames (without the full path):
if os.path.exists(path+'/Calibration_spectra/histogram_names.txt'):
    os.remove(path+'/Calibration_spectra/histogram_names.txt')

#==========================================================
# Plot the 3keV and 6keV peaks as a funtion of runs.

peak_3kev = np.loadtxt("Calibration_spectra/fitted_peaks.dat", usecols=(1,), dtype='float', skiprows=1)
peak_6kev = np.loadtxt("Calibration_spectra/fitted_peaks.dat", usecols=(3,), dtype='float', skiprows=1)
peak_3kev_err = np.loadtxt("Calibration_spectra/fitted_peaks.dat", usecols=(2,), dtype='float', skiprows=1)
peak_6kev_err = np.loadtxt("Calibration_spectra/fitted_peaks.dat", usecols=(4,), dtype='float', skiprows=1)

x=np.arange(start=1, stop=peak_3kev.size+1, step=1)
plt.errorbar(x, peak_3kev, yerr=peak_3kev_err, marker='o', ls='none', label="3 keV peak")
plt.errorbar(x, peak_6kev, yerr=peak_6kev_err, marker='o', ls='none', label="3 keV peak")

plt.ylabel('ADC')
plt.ylim(0, 21000)
plt.grid()
plt.xlabel('Calibration runs')
plt.title('Calibration peak position')
plt.legend(loc='lower right')
plt.savefig('Calibration_spectra/calibration_peaks.png')
# TO DO: add run numbers as label in x axis.

#################################################################
# GENERATE RAW BACKGROUND

# !!! The histograms must be generated with the same parameters
# specified in the configuration file !!!

#================================================================
# Write the rml files to generate the 3keV and 6keV histograms.
# An external script rml_generator.py is called:

energy_range = "3keV" #chose 3keV or 5.9keV
output_type='png'
rml_3kev_filename_png = 'histoEnergy_'+output_type+'_'+energy_range+'.rml'
bashCommand = 'python '+path+'/Background/Raw_Background/rml_generator.py '+path+' '+rml_3kev_filename_png+' '+energy_range+' '+output_type #Arguments: main_path    file_name.rml    energy_range    output_type
os.system(bashCommand)

output_type='root'
rml_3kev_filename_root = 'histoEnergy_'+output_type+'_'+energy_range+'.rml'
bashCommand = 'python '+path+'/Background/Raw_Background/rml_generator.py '+path+' '+rml_3kev_filename_root+' '+energy_range+' '+output_type #Arguments: main_path    file_name.rml    energy_range     output_type
os.system(bashCommand)

energy_range = "5.9keV" #chose 3keV or 5.9keV
output_type='png'
rml_6kev_filename_png =  'histoEnergy_'+output_type+'_'+energy_range+'.rml'
bashCommand = 'python '+path+'/Background/Raw_Background/rml_generator.py '+path+' '+rml_6kev_filename_png+' '+energy_range+' '+output_type #Arguments: main_path    file_name.rml    energy_range     output_type
os.system(bashCommand)

output_type='root'
rml_6kev_filename_root =  'histoEnergy_'+output_type+'_'+energy_range+'.rml'
bashCommand = 'python '+path+'/Background/Raw_Background/rml_generator.py '+path+' '+rml_6kev_filename_root+' '+energy_range+' '+output_type #Arguments: main_path    file_name.rml    energy_range     output_type
os.system(bashCommand)

#================================================================
# Write the sh file with the list of REST commands to generate
# the 3keV and 6keV histograms for the raw background computation
# (full detector area, no cuts, only track in x and y >0): 

# Read analyzed background-runs list:
analyzed_background_file = np.loadtxt(file_analyzed_bg, dtype=np.str)

# Retrieve the calibration run numbers:
run_number = np.loadtxt("Calibration_spectra/fitted_peaks.dat", usecols=(0,), dtype='str', skiprows=1)

# Retrieve the limits of energy ranges in ADC:
ZERO_KEV = np.loadtxt("Calibration_spectra/fitted_peaks.dat", usecols=(6,), dtype='str', skiprows=1)    # 0 keV --> independent term
LIMIT_3 = np.loadtxt("Calibration_spectra/fitted_peaks.dat", usecols=(7,), dtype='str', skiprows=1)     # 3.8 keV 
LIMIT_10 = np.loadtxt("Calibration_spectra/fitted_peaks.dat", usecols=(8,), dtype='str', skiprows=1)    # 10 keV
TWELVE_KEV = np.loadtxt("Calibration_spectra/fitted_peaks.dat", usecols=(9,), dtype='str', skiprows=1)  # 12 keV


file_histo_bg=path+"/Background/Raw_Background/Run_3-6KeV_histo.sh"

if os.path.exists(file_histo_bg):
    os.remove(file_histo_bg)

file6 = open(file_histo_bg, 'a')
file6.write('#!/bin/bash\n')	
for i in range (0,analyzed_background_file.size):
    s0='\nexport '+ZERO_KEV[i]+'\nexport LIMIT_3='+LIMIT_3[i]+'\nexport LIMIT_10='+LIMIT_10[i]+'\nexport TWELVE_KEV='+TWELVE_KEV[i]+'\n\n'
    s1='restManager --c ' +path+'/Background/Raw_Background/'+rml_3kev_filename_root+ ' --f '+analyzed_background_file[i]+'\n\n'
    s2='restManager --c ' +path+'/Background/Raw_Background/'+rml_6kev_filename_root+ ' --f '+analyzed_background_file[i]+'\n\n'
    s3='restManager --c ' +path+'/Background/Raw_Background/'+rml_3kev_filename_png+ ' --f '+analyzed_background_file[i]+'\n\n'
    s4='restManager --c ' +path+'/Background/Raw_Background/'+rml_6kev_filename_png+ ' --f '+analyzed_background_file[i]+'\n\n'
    file6.write(s0)
    file6.write(s1)
    file6.write(s2)
    file6.write(s3)
    file6.write(s4)	
file6.close()

#================================================================
# Run the bash script to generate the 3 and 6 keV bg histograms (both in root and png):
bashCommand = '. '+file_histo_bg
os.system(bashCommand)

#================================================================
# Write the list of all the histograms:

if os.path.exists(path+'/Background/Raw_Background/list_histogram.txt'):
    os.remove(path+'/Background/Raw_Background/list_histogram.txt')

bashCommand = 'ls '+path+'/Background/Raw_Background/*root >>'+path+'/Background/Raw_Background/list_histogram.txt'
os.system(bashCommand)

# Read the list:
list_histograms = np.loadtxt('Background/Raw_Background/list_histogram.txt', dtype=np.str)

#================================================================
# Retrieve information to write the config file used by histoSumCal.C (the script that
# computes the bg calibrated spectrum):

filename_config_rawbg = path+"/Background/Raw_Background/config_RawBG_NOCuts.txt"

if os.path.exists(filename_config_rawbg):
    os.remove(filename_config_rawbg)

# Retrieve the relation ADC-keV (slope and independent term):
slope = np.loadtxt("Calibration_spectra/fitted_peaks.dat", usecols=(5,), dtype='str', skiprows=1)
coeff = np.loadtxt("Calibration_spectra/fitted_peaks.dat", usecols=(6,), dtype='str', skiprows=1)

# Extrapolate the background run number and observation time from list_background_runs.txt:
obs_time = np.array([],dtype=str)
bg_run_number = np.array([],dtype=str)
for i in range (0,background_list.size):
    obs_time = np.append(obs_time, int(background_list[i][18:20])*3600)
    bg_run_number = np.append(bg_run_number, background_list[i][0:6])

# Read analyzed background-runs list:
#analyzed_background_file = np.loadtxt(file_analyzed_bg, dtype=np.str)

# Write the config file:
file7 = open(filename_config_rawbg, 'w')
file7.write('Number_of_files_to_be_included '+str(list_histograms.size)+'\n\n')
file7.write('Integration_from_to_(keV)\n0.4 10\n\n')
file7.write('FileName__Calibration(ACQ/keV)__IndependentTerm__CalibrationTime_Active_surface_or_volume(cm2)_Name\n\n')
for j in range (0,list_histograms.size):
    for i in range (0, analyzed_background_file.size):
        if bg_run_number[i] in list_histograms[j]:
            file7.write(list_histograms[j]+'\t'+slope[i]+'\t'+coeff[i]+'\t'+obs_time[i]+'\t'+'36'+'\t'+bg_run_number[i]+'\n\n')
file7.close()

#================================================================
# Write the file to run the histoSumCal.C with restRoot:

file_compute_raw_bg=path+"/Background/Raw_Background/Run_compute_raw_bg.sh"

if os.path.exists(file_compute_raw_bg):
    os.remove(file_compute_raw_bg)

file8 = open(file_compute_raw_bg, 'a')
file8.write('#!/bin/bash\n')
file8.write('restRoot <<EOF\n')
file8.write('.x '+path+'/Background/Raw_Background/histoSumCal.C("'+filename_config_rawbg+'");\n')
file8.write('EOF\n')
file8.close() 

#================================================================
# Remove result file if it exists:
if os.path.exists('Background/Raw_Background/Plot/results_raw_bg.dat'):
    os.remove('Background/Raw_Background/Plot/results_raw_bg.dat')

# Run the bash script to generate the raw bg spectrum (both in root and png):
bashCommand = '. '+file_compute_raw_bg
os.system(bashCommand)









