// histograms filled and drawn in a loop
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
#include "TMath.h"

void histoSumCal(string histofile) {

    gBenchmark->Start("histoCalSum");

    // Initialization and config read

    cout<<"--------------------------------------------------"<<endl;
    cout<<" CALIBRATION SPECTRA SUM SCRIPT - E. Ruiz Choliz / G. Luzon "<<endl;
    cout<<" Adapted for IAXO-D0 2020 runs by C. Margalejo and S. Schmidt "<<endl;
    cout<<" Modified by Barbara Biasuzzi (May 2020)"<<endl;
    cout<<"--------------------------------------------------"<<endl;

    // It is now passed as an argument
    //string histofile;
    //cout<<"Enter config file for histograms to be compared (be sure they are data calibration spectra!)"<<endl;
    //cin>>histofile;

    ifstream in;
    in.open(histofile.c_str());
    cout<<"--------------------------------------------------"<<endl;
    cout<<"Config file opened"<<endl;
    string info0, info1, info2;
  
    string fi[5000];
    float bine[5000], rt[5000], ac[5000], iener, fener, integral[5000], ierror[5000], cal[5000], ind[5000];
    Double_t rtTot=0, intTot=0, ierrorTot=0, backg=0, backgError=0;
    string name[5000];
    int nlines = 0;
    int n=0;
    int i;
    
    in>>info0>>nlines;  
    cout<<"number of files to be included "<<nlines<<endl;
    in>>info1>>iener>>fener;
    cout<<"Integrated values from "<<iener<<" (eV) to "<<fener<<" (eV) will be given "<<endl;
    in>>info2;
    cout<<info2<<endl;

    while(!in.fail())
    {  
        in>>fi[n]>>cal[n]>>ind[n]>>rt[n]>>ac[n]>>name[n];
    
        if (in.good())cout<<fi[n]<<" calibration: "<<cal[n]<<" ind term: "<<ind[n]<<" run time (s):" <<rt[n]<< " active volume (kg or cm2): " <<ac[n]<< " Name " <<name[n]<<endl;
        n++;
    }
   
    if(n<nlines) nlines=n-1;
    
    in.close();
    cout<<"--------------------------------------------------"<<endl;
    cout<<"==>Found "<<nlines<<" files to be plotted!!!"<<endl;
    cout<<"--------------------------------------------------"<<endl;

    // Definition of plots
	const int bin_range_upper = 12.0;
	const int num_bins = 48;

    TCanvas *cs = new TCanvas("cs","Energy spectrum",200,10,1280,720);
      
    TH1D *h[5000], *hcal[5000];
    TH1D *hsum = new TH1D("hsum", "hsum", num_bins, 0, bin_range_upper);

    TCanvas *c[5000]; 
    TFile*f[5000];

    Double_t MaxY[5000], MaxY_s=0, norm[5000];
    Int_t NEntries[5000];

    Float_t nb[5000], nb_cal[5000], nb_cal_int[5000]; 
    Double_t lbv[5000], lbv_cal[5000], lbv_cal_ind[5000]; 
    Double_t bincontent[5000], totInt=0.0, totTime=0.0;
    //Double_t bincontent[1000]=0.0, totInt=0.0, totTime=0.0;
    Float_t Binning, calBinning, sumBinning, calBin, calValue, histoCalValue;


    for(i=0; i<nlines; i++)
    {
        char *file = new char[fi[i].length() + 1];
        std::strcpy(file, fi[i].c_str());
        f[i] = new TFile(file,"read");

		h[i] = (TH1D*)f[i]->Get("HitsEnergy");
		

        nb[i]=h[i]->GetNbinsX(); // Number of bins of the X axis of the ACQ histogram
        lbv[i]=h[i]->GetBinCenter(nb[i])+h[i]->GetBinWidth(0)/2; // X value of the last bin of the ACQ histogram
        Binning=h[i]->GetBinWidth(0); // Binning of the ACQ histogram

        lbv_cal_ind[i] = (lbv[i]-ind[i])/cal[i]; // Last bin value of the calibrated histogram in keV including independent term
        lbv_cal[i] = lbv[i]/cal[i]; // Last bin value of the calibrated histogram in keV


        //hcal[i] = new TH1D ("hcal", "hcal", nb[i], 0, lbv_cal_ind[i]); // Calibrated histogram with a fixed binning of 0.25keV. To be used when calibration is precise
		hcal[i] = new TH1D ("hcal", "hcal", num_bins, 0, bin_range_upper);

        calBinning=hcal[i]->GetBinWidth(0); // Binning of the calibrated histogram

        cout<<"--------------------------------------------------"<<endl;
        cout<< " Bin size: " << h[i]->GetBinWidth(0)  << " || Number of bins: " << nb[i] << " || Binning: " << Binning << " || Last bin value: " << lbv[i] << " || Calibration: " << cal[i] << " || New number of bins: " << nb_cal[i] << " || calBinning: " << calBinning << " || New last bin value (keV): " << lbv_cal[i] << " || New last bin vaule inc. ind [i] " << lbv_cal_ind[i] << " || New last bin: " << hcal[i]->GetNbinsX() << " and " << h[i]->GetBinContent(nb[i] + 1) << endl;

        for (int j=0;j<nb[i]+1;j++)
        {  
 			// we fill the calibrated histogram
   			hcal[i]->SetBinContent(j, h[i]->GetBinContent(j));
			// we fill the sum histogram
			bincontent[j] = bincontent[j] + hcal[i]->GetBinContent(j);
            hsum->SetBinContent(j, bincontent[j]);
        }

        cout << " Integral between bins: (" << iener/calBinning << " , " << fener/calBinning <<")" << endl;

        totInt = totInt + hcal[i]->Integral(iener/calBinning,fener/calBinning); // To calculate the total background error

	//##########################
        //totTime = totTime + rt[i]; // To obtain the total time (s) of the runs considered
        //MODIFICATION
	//cout << "Total time prima di entrare nel ciclo " << totTime << endl;
        if (name[i]!=0 && name[i]!=name[i-1]){
	  //cout << "\n ENTRATO NEL CICLO, iterazione " << i << endl;
	  totTime = totTime + rt[i];
	  //cout << "\n TOT TIME " << totTime << endl;
	}
	//cout << "TotTime USCITO DAL CICLO: " << i << " totTime = " << totTime << endl; 

	//############################
        ierror[i]= TMath::Sqrt(hcal[i]->Integral(iener/calBinning,fener/calBinning));

        NEntries[i]=hcal[i]->GetEntries();
        norm[i] = 1/(rt[i]*ac[i]);
        hcal[i]->Scale(norm[i]); 

        integral[i]=hcal[i]->Integral(iener/calBinning,fener/calBinning)/(fener-iener);

        ierror[i]=integral[i]/ierror[i];

        cout<<"--------------------------------------------------"<<endl;
        cout<<" BACKGROUND hcal[" << i << "]: "<<integral[i]<<" counts/(keV cm2 s) in range ("<<iener<<"-"<<fener<<") keV and error "<<ierror[i]<<endl;
        cout<<"--------------------------------------------------"<<endl;
        cout<<"\n TOTAL TIME: "<<totTime/3600 << " hours\n" << endl; 
        delete[] file;
    }
   
    Double_t integral_sum, ierror_sum, norm_sum;

    sumBinning = hsum->GetBinWidth(0);
    ierror_sum = TMath::Sqrt(hsum->Integral(iener/sumBinning,fener/sumBinning));
    //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    norm_sum = 1/(totTime/1*ac[0]);
    //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    hsum->Scale(norm_sum); 
    integral_sum = hsum->Integral(iener/sumBinning,fener/sumBinning)/(fener-iener);
    ierror_sum = integral_sum/ierror_sum;
    //ierror_sum = integral_sum/TMath::Sqrt(totInt);

    cout<<"--------------------------------------------------"<<endl;
        cout<< " Bin size: " << sumBinning  << " || Number of bins: " << hsum->GetNbinsX() << " || Last bin value: " << hsum->GetBinCenter(hsum->GetNbinsX()) << endl;

    cout<<"--------------------------------------------------"<<endl;
    cout<<" TOTAL BACKGROUND: "<<integral_sum<<" counts/(keV cm2 s) in range ("<<iener<<"-"<<fener<<") eV and error "<<ierror_sum<<endl;
    cout<<"--------------------------------------------------"<<endl;

    hsum->Scale(1/sumBinning); // To express the plot in c/(keV cm2 s) despite the binning

    gStyle->SetOptTitle(0);

    hsum->GetYaxis()->SetTitle("counts/(keV cm2 s)");
    hsum->GetXaxis()->SetTitle("Energy (keV)");

    cs->cd();   

    hsum->SetLineColor(4);
    hsum->Draw();

    cs->Update();

    // Print histograms into pdf file:
    cs->Print("Background/Raw_Background/Plot/Raw_Background_FullArea.png");

    //Print histogram into root file:
    TFile *outputFile = new TFile("Background/Raw_Background/Plot/Raw_Background_FullArea.root","RECREATE");
    hsum->Write("hsum");
    outputFile->Close();

    //Print results on file
    int n_bins = hsum->GetNbinsX();
    FILE *fp = fopen("Background/Raw_Background/Plot/results_raw_bg.dat","a");
    fprintf(fp,"Bg \t bg_err \t en_min \t en_max \t n_bins \t time[h]\n");
    fprintf(fp,"%2e \t %2e \t %2f \t %2f \t %i \t %1f",integral_sum, ierror_sum, iener, fener, n_bins, totTime/3600);
    fprintf(fp,"\n");
    fclose(fp);
 
    gBenchmark->Show("histoCalSum");

}
 
