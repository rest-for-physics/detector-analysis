#include "TCanvas.h"
#include "TFrame.h"
#include "TBenchmark.h"
#include "TString.h"
#include "TF1.h"
#include "TH1.h"
#include "TFile.h"
#include "TROOT.h"
#include "TError.h"
#include "TInterpreter.h"
#include "TSystem.h"
#include "TPaveText.h"
#include <string>
#include <iostream>


void fit_the_peaks(TString fileName, TString calibration_run) {

   
   gROOT->SetBatch(kTRUE);
  
   TCanvas *c1 = new TCanvas("c1_fit1","The Fit Canvas",200,10,700,500);
   c1->SetGridx();
   c1->SetGridy();
   c1->GetFrame()->SetFillColor(21);
   c1->GetFrame()->SetBorderMode(-1);
   c1->GetFrame()->SetBorderSize(5);

   TFile *file = TFile::Open(fileName);
   //file->ls();

   TH1F *h = (TH1F*)file->Get("HitsEnergy");
   //h->Print();
   Int_t NEntries = h->GetEntries();
   cout<< "NEntries = " << NEntries <<endl;

   // ----- Plot the spectra
   gStyle->SetOptTitle(0);
   h->GetYaxis()->SetTitle("Counts");
   h->GetXaxis()->SetTitle("Channels");

   // ----- FIT THE 3 keV peak
   TF1 *f1 = new TF1("f1","gaus",5000,13000);
   //f1->SetParameters(h->GetMaximum(), h->GetMean(), h->GetRMS() ); //set initial parameters
   f1->SetLineColor(4);
   h->Fit("f1","R");
   Double_t peak_3kev  = f1->GetParameter(1);
   Double_t peak_3kev_err = f1->GetParError(1);
   //Double_t chi_square_3keV = f1->Chi2()

   // ----- FIT THE 6 keV peak
   TF1 *f2 = new TF1("f2","gaus",13000,25000);
   //f1->SetParameters(h->GetMaximum(), h->GetMean(), h->GetRMS() ); //Set initial parameters.
   h->Fit("f2","R+");
   Double_t peak_6kev  = f2->GetParameter(1);
   Double_t peak_6kev_err = f2->GetParError(1);
   //Double_t chi_square_6keV = f2->Chi2();

   // ----- Interpolate the two peaks
   //TF1 *f2 = new TF1("f2","gaus",13000,25000);
   Double_t y_peak_3kev, y_peak_6kev;
   y_peak_3kev=f1->Eval(peak_3kev);
   y_peak_6kev=f2->Eval(peak_6kev);

   Double_t m = (peak_6kev-peak_3kev)/(5.9-3);
   Double_t q = peak_3kev - m*3;

   //Compute other energy limits in ADC:
   Double_t lim_sup_3kev = m*3.8 + q; // ADCs that correspond to 3.8 keV
   Double_t lim_sup_6kev = m*10 + q; // ADC that  correspond to 10 keV
   Double_t lim_12kev = m*12 + q; // ADC that  correspond to 12 keV
     
   
   // ----- Save plot into file
   TString run_number(calibration_run (47,6) ); //Extract run number from filename.
   TString plot_name = "_spectrum.png";
   TString plot_filename = run_number+plot_name;
   const char *a = (const char*)run_number;


   // ----- Save parameters into a file
   FILE *fp = fopen("Calibration_spectra/fitted_peaks.dat","a");
   // If you modify this line, you should update the first description line of the file specified in Run_Analysis.py 
   fprintf(fp,"%s \t %2f \t %2f \t %2f \t %2f \t %2f \t %2f \t %3f \t %3f \t %3f", a, peak_3kev, peak_3kev_err, peak_6kev, peak_6kev_err, m, q, lim_sup_3kev, lim_sup_6kev,lim_12kev );
   fprintf(fp,"\n");
   fclose(fp);

   
   c1->SaveAs(plot_filename);

}
